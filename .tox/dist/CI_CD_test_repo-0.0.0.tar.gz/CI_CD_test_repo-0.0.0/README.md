# Tensorflow lite audio classification training pipeline UI
![Tests](https://github.com/fentresspaul61B/audio_to_image_model_training/actions/workflows/tests.yml/badge.svg)

Tensorflow lite audio classification training pipeline UI. 
